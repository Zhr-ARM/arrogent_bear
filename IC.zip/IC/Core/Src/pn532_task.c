/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : pn532_task.c
 * @brief          : PN532 IC Card Reader Task Implementation
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "pn532_task.h"
#include "cmsis_os.h"
#include "main.h"
#include "pn532.h"
#include <stdio.h>
#include <string.h>

/* Private variables ---------------------------------------------------------*/
osThreadId PN532_ICCardTaskHandle = NULL;
PN532_ReadResult g_last_read_result = {0};
static bool pn532_initialized = false;
/* ��λ��Ϣȫ�ֱ��� */
PeakInfo g_peak_info = {0};

/* ��1�Ϳ�2���ݱ��� */
uint8_t g_block1_array[4] = {0}; // ��1���飨ֻ�����������ݣ�
int g_block1_array_size = 0;     // ��1�����С
uint8_t g_block2_first_byte = 0; // ��2��һ���ֽ�

/* External variables --------------------------------------------------------*/
extern UART_HandleTypeDef huart4; // ���Դ���
extern UART_HandleTypeDef huart6; // PN532ͨ�Ŵ���
extern uint16_t uart6_rx_index;
extern uint8_t uart6_rx_buffer[256];

/* Private function prototypes -----------------------------------------------*/
static void PN532_Init_Hardware(void);
static bool PN532_SearchCard(uint8_t *uid, uint8_t *uid_length);
static bool PN532_ReadAllSectors(PN532 *pn532, PN532_ReadResult *result);

/* ============================================================================
   ���Ķ���������ͬ��ִ�У�
   ============================================================================
 */
/**
 * @brief ���ݵ�ַ������������ź��ֽ�ƫ��
 */
static bool CalculateAddress(uint16_t channel, uint8_t *sector, uint8_t *block, uint8_t *byte_offset) {
    if (channel >= 720) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��ַ������Χ\r\n", 24, 1000);
        return false;
    }
    
    // ÿ��������48�ֽ� (3�� �� 16�ֽ�)
    *sector = (channel / 48) + 1;  // ����1-15
    
    uint16_t offset_in_sector = channel % 48;
    *block = offset_in_sector / 16;  // ��0-2
    *byte_offset = offset_in_sector % 16;  // �ֽ�0-15
    
    char msg[80];
    sprintf(msg, "[Peak] ��ַ%d -> ����%d ��%d ƫ��%d\r\n", 
            channel, *sector, *block, *byte_offset);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    return true;
}

/**
 * @brief ��ȡָ��������ݣ�������֤��
 */
static bool ReadBlockSelective(PN532 *pn532, uint8_t *uid, uint8_t uid_length,
                               uint8_t sector, uint8_t block, uint8_t *data) {
    uint8_t key[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    uint8_t block_addr = sector * 4 + block;
    
    char msg[60];
    sprintf(msg, "[Peak] ��֤����%d...\r\n", sector);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    // ��֤����
    if (PN532_MifareClassicAuthenticate_UART(pn532, uid, uid_length, 
                                             sector * 4, key, 0x60) != PN532_STATUS_OK) {
        sprintf(msg, "[Peak] ����%d��֤ʧ��\r\n", sector);
        HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
        return false;
    }
    
    vTaskDelay(50);
    
    sprintf(msg, "[Peak] ��ȡ��%d...\r\n", block_addr);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    // ��ȡ������
    if (PN532_MifareClassicReadWithUID_UART(pn532, block_addr, data, uid, uid_length) != PN532_STATUS_OK) {
        sprintf(msg, "[Peak] ��%d��ȡʧ��\r\n", block_addr);
        HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
        return false;
    }
    
    // ��ӡ����
    sprintf(msg, "[Peak] ��%d: ", block_addr);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    for (int i = 0; i < 16; i++) {
        char hex[5];
        sprintf(hex, "%02X ", data[i]);
        HAL_UART_Transmit(&huart4, (uint8_t*)hex, 3, 1000);
    }
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n", 2, 1000);
    
    return true;
}

/**
 * @brief �ӿ���������ȡ3�ֽڷ�ֵ����
 */
/**
 * @brief �ӿ���������ȡ3�ֽڷ�ֵ����
 */
static bool ExtractPeakData(PN532 *pn532, uint8_t *uid, uint8_t uid_length,
                           uint8_t sector, uint8_t block, uint8_t byte_offset,
                           uint8_t *block_data, uint8_t *peak_data) {
    
    // ����������ǰ�ƶ�1λ���� byte_offset-1 ��ʼ��ȡ
    if (byte_offset == 0) {
        // �����������Ҫ����һ��������һ���ֽڿ�ʼ
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��飺��Ҫ��һ��\r\n", 27, 1000);
        
        uint8_t prev_sector = sector;
        uint8_t prev_block = block - 1;
        
        if (block == 0) {
            // ��Ҫ��һ�������Ŀ�2
            if (sector == 1) {
                HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ������Χ\r\n", 18, 1000);
                return false;
            }
            prev_sector = sector - 1;
            prev_block = 2;
        }
        
        uint8_t prev_data[16];
        if (!ReadBlockSelective(pn532, uid, uid_length, prev_sector, prev_block, prev_data)) {
            return false;
        }
        
        peak_data[0] = prev_data[15];
        peak_data[1] = block_data[0];
        peak_data[2] = block_data[1];
        
    } else if (byte_offset == 1) {
        // �����������Ҫ����һ������1�ֽ�
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��飺��Ҫ��һ��1�ֽ�\r\n", 33, 1000);
        
        uint8_t prev_sector = sector;
        uint8_t prev_block = block - 1;
        
        if (block == 0) {
            if (sector == 1) {
                HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ������Χ\r\n", 18, 1000);
                return false;
            }
            prev_sector = sector - 1;
            prev_block = 2;
        }
        
        uint8_t prev_data[16];
        if (!ReadBlockSelective(pn532, uid, uid_length, prev_sector, prev_block, prev_data)) {
            return false;
        }
        
        peak_data[0] = prev_data[15];
        peak_data[1] = block_data[0];
        peak_data[2] = block_data[1];
        
    } else if (byte_offset <= 14) {
        // ���������3�ֽ���ͬһ���ڣ��� byte_offset-1 ��ʼ
        peak_data[0] = block_data[byte_offset - 1];
        peak_data[1] = block_data[byte_offset];
        peak_data[2] = block_data[byte_offset + 1];
        
    } else if (byte_offset == 15) {
        // ��飺��Ҫ��һ���1�ֽ�
        peak_data[0] = block_data[14];
        peak_data[1] = block_data[15];
        
        uint8_t next_sector = (block == 2) ? sector + 1 : sector;
        uint8_t next_block = (block == 2) ? 0 : block + 1;
        
        if (next_sector > 15) {
            HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ������Χ\r\n", 18, 1000);
            return false;
        }
        
        uint8_t next_data[16];
        if (!ReadBlockSelective(pn532, uid, uid_length, next_sector, next_block, next_data)) {
            return false;
        }
        peak_data[2] = next_data[0];
    }
    
    char msg[100];
    sprintf(msg, "[Peak] ��ֵ: %02X %02X %02X (ʮ����: %u %u %u)\r\n",
            peak_data[0], peak_data[1], peak_data[2],
            peak_data[0], peak_data[1], peak_data[2]);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    return true;
}

/**
 * @brief ѡ���Զ�ȡ��λ��Ϣ��ֻ����Ҫ�Ŀ飩
 */
bool PN532_ReadPeakInfoSelective(PN532 *pn532, uint8_t *uid, uint8_t uid_length, PeakInfo *peak_info) {
    uint8_t key[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    uint8_t block1_data[16];
    
    memset(peak_info, 0, sizeof(PeakInfo));
    
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n===== ��ȡ��λ��Ϣ =====\r\n", 30, 1000);
    
    // ����1����ȡ����0��1
    HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��ȡ����0��1...\r\n", 24, 1000);
    
    if (PN532_MifareClassicAuthenticate_UART(pn532, uid, uid_length, 0, key, 0x60) != PN532_STATUS_OK) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ����0��֤ʧ��\r\n", 22, 1000);
        return false;
    }
    
    vTaskDelay(50);
    
    if (PN532_MifareClassicReadWithUID_UART(pn532, 1, block1_data, uid, uid_length) != PN532_STATUS_OK) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��1��ȡʧ��\r\n", 20, 1000);
        return false;
    }
    
    // ��ӡ��1����
    HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��1: ", 12, 1000);
    for (int i = 0; i < 16; i++) {
        char hex[5];
        sprintf(hex, "%02X ", block1_data[i]);
        HAL_UART_Transmit(&huart4, (uint8_t*)hex, 3, 1000);
    }
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n", 2, 1000);
    
    // ���ؼ�������������0������2��ȡ��λ��ַ
    peak_info->peak1_channel = block1_data[0];  // ��1�ֽڣ�����0��
    peak_info->peak2_channel = block1_data[2];  // ��3�ֽڣ�����2��
    
    char msg[100];
    sprintf(msg, "[Peak] ��λ: ��1=%d��(0x%02X), ��2=%d��(0x%02X)\r\n", 
            peak_info->peak1_channel, peak_info->peak1_channel,
            peak_info->peak2_channel, peak_info->peak2_channel);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    vTaskDelay(100);
    
    // ����2����ȡ��1����
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n[Peak] ��ȡ��1����...\r\n", 26, 1000);
    
    uint8_t sector1, block1, offset1;
    if (!CalculateAddress(peak_info->peak1_channel, &sector1, &block1, &offset1)) {
        return false;
    }
    
    uint8_t peak1_block_data[16];
    if (!ReadBlockSelective(pn532, uid, uid_length, sector1, block1, peak1_block_data)) {
        return false;
    }
    
    if (!ExtractPeakData(pn532, uid, uid_length, sector1, block1, offset1, 
                        peak1_block_data, peak_info->peak1_data)) {
        return false;
    }
    
    vTaskDelay(100);
    
    // ����3����ȡ��2����
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n[Peak] ��ȡ��2����...\r\n", 26, 1000);
    
    uint8_t sector2, block2, offset2;
    if (!CalculateAddress(peak_info->peak2_channel, &sector2, &block2, &offset2)) {
        return false;
    }
    
    uint8_t peak2_block_data[16];
    
    // �Ż���ͬһ����������
    if (sector2 == sector1 && block2 == block1) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[Peak] ��2���1ͬ�飬����\r\n", 28, 1000);
        memcpy(peak2_block_data, peak1_block_data, 16);
    } else {
        if (!ReadBlockSelective(pn532, uid, uid_length, sector2, block2, peak2_block_data)) {
            return false;
        }
    }
    
    if (!ExtractPeakData(pn532, uid, uid_length, sector2, block2, offset2, 
                        peak2_block_data, peak_info->peak2_data)) {
        return false;
    }
    
    peak_info->valid = true;
    
    // ����
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n===== ��λ���� =====\r\n", 26, 1000);
    
    sprintf(msg, "��1: %d��, ����=[%02X %02X %02X] (ʮ����:[%u %u %u])\r\n",
            peak_info->peak1_channel,
            peak_info->peak1_data[0], peak_info->peak1_data[1], peak_info->peak1_data[2],
            peak_info->peak1_data[0], peak_info->peak1_data[1], peak_info->peak1_data[2]);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    sprintf(msg, "��2: %d��, ����=[%02X %02X %02X] (ʮ����:[%u %u %u])\r\n",
            peak_info->peak2_channel,
            peak_info->peak2_data[0], peak_info->peak2_data[1], peak_info->peak2_data[2],
            peak_info->peak2_data[0], peak_info->peak2_data[1], peak_info->peak2_data[2]);
    HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 1000);
    
    HAL_UART_Transmit(&huart4, (uint8_t*)"====================\r\n\r\n", 24, 1000);
    
    return true;
}

PN532_ReadResult PN532_ReadCard_Once(void) {
  PN532_ReadResult result = {0};
  PN532 pn532;
  uint8_t key[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};

  HAL_UART_Transmit(
      &huart4, (uint8_t *)"[PN532] === ReadCard_Once Start ===\r\n", 38, 1000);

  // ��ʼ��PN532Ӳ�������״�ִ�У�
  if (!pn532_initialized) {
    HAL_UART_Transmit(
        &huart4, (uint8_t *)"[PN532] First run, initializing...\r\n", 36, 1000);
    PN532_Init_Hardware();
    pn532_initialized = true;
    HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Init completed\r\n", 24,
                      1000);
  } else {
    HAL_UART_Transmit(
        &huart4, (uint8_t *)"[PN532] Already initialized, skip\r\n", 35, 1000);
  }

  // Ѱ��
  HAL_UART_Transmit(&huart4,
                    (uint8_t *)"[PN532] Step 1: Searching for card...\r\n", 40,
                    1000);

  if (!PN532_SearchCard(result.uid, &result.uid_length)) {
    HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] ERROR: No card detected\r\n",
                      33, 1000);
    return result;
  }

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Step 2: Card found!\r\n", 29,
                    1000);

  // ��ӡUID
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Card UID (", 18, 1000);
  char len_str[5];
  sprintf(len_str, "%d", result.uid_length);
  HAL_UART_Transmit(&huart4, (uint8_t *)len_str, strlen(len_str), 1000);
  HAL_UART_Transmit(&huart4, (uint8_t *)" bytes): ", 9, 1000);

  for (int i = 0; i < result.uid_length; i++) {
    char hex[5];
    sprintf(hex, "%02X ", result.uid[i]);
    HAL_UART_Transmit(&huart4, (uint8_t *)hex, 3, 1000);
  }
  HAL_UART_Transmit(&huart4, (uint8_t *)"\r\n", 2, 1000);

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Step 3: Wait 50ms...\r\n", 30,
                    1000);
  vTaskDelay(50); // ���ݵȴ������������ͻ

  // ��֤����ȡ��������
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Step 4: Authenticating...\r\n",
                    35, 1000);

  pn532.uart_handle = &huart6;

  if (PN532_MifareClassicAuthenticate_UART(&pn532, result.uid,
                                           result.uid_length, 1, key,
                                           0x60) == PN532_STATUS_OK) {

    HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] Authentication OK!\r\n", 28,
                      1000);

    HAL_UART_Transmit(&huart4,
                      (uint8_t *)"[PN532] Step 5: Reading all sectors...\r\n",
                      40, 1000);

    if (PN532_ReadAllSectors(&pn532, &result)) {
      result.success = true;
      result.timestamp = HAL_GetTick();
      HAL_UART_Transmit(
          &huart4, (uint8_t *)"[PN532] Card reading completed!\r\n", 33, 1000);
    } else {
      HAL_UART_Transmit(&huart4,
                        (uint8_t *)"[PN532] ERROR: Failed to read sectors\r\n",
                        39, 1000);
    }
  } else {
    HAL_UART_Transmit(&huart4,
                      (uint8_t *)"[PN532] ERROR: Authentication failed\r\n", 38,
                      1000);
  }

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532] === ReadCard_Once End ===\r\n",
                    35, 1000);

  return result;
}

/* ============================================================================
   FreeRTOS�����װ��
   ============================================================================
 */void StartPN532_ICCardTask(void const *argument) {
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n========================================\r\n", 42, 1000);
    HAL_UART_Transmit(&huart4, (uint8_t*)"[PN532 Task] ��������\r\n", 24, 1000);
    HAL_UART_Transmit(&huart4, (uint8_t*)"========================================\r\n\r\n", 44, 1000);

    vTaskDelay(500);

    // ��ʼ��
    if (!pn532_initialized) {
        PN532_Init_Hardware();
        pn532_initialized = true;
    }

    // Ѱ��
    uint8_t uid[7];
    uint8_t uid_length;
    
    if (!PN532_SearchCard(uid, &uid_length)) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[PN532 Task] δ���ֿ�Ƭ\r\n", 26, 1000);
        goto task_end;
    }

    // ��ӡUID
    HAL_UART_Transmit(&huart4, (uint8_t*)"[PN532 Task] UID: ", 18, 1000);
    for (int i = 0; i < uid_length; i++) {
        char hex[5];
        sprintf(hex, "%02X ", uid[i]);
        HAL_UART_Transmit(&huart4, (uint8_t*)hex, 3, 1000);
    }
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n", 2, 1000);

    vTaskDelay(200);

    // ��ȡ��λ��Ϣ
    PN532 pn532;
    pn532.uart_handle = &huart6;
    
    if (PN532_ReadPeakInfoSelective(&pn532, uid, uid_length, &g_peak_info)) {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[PN532 Task] *** ��ȡ�ɹ� ***\r\n", 32, 1000);
    } else {
        HAL_UART_Transmit(&huart4, (uint8_t*)"[PN532 Task] *** ��ȡʧ�� ***\r\n", 32, 1000);
    }

task_end:
    HAL_UART_Transmit(&huart4, (uint8_t*)"\r\n[PN532 Task] �������\r\n", 26, 1000);
    vTaskDelay(1000);

    PN532_ICCardTaskHandle = NULL;
    vTaskDelete(NULL);
}

/* ============================================================================
   �ⲿ���ýӿ�
   ============================================================================
 */
bool PN532_StartReadTask(void) {
  // ��������Ƿ��Ѵ���
  if (PN532_ICCardTaskHandle != NULL) {
    HAL_UART_Transmit(
        &huart4,
        (uint8_t *)"[PN532 API] Task already running, please wait...\r\n", 50,
        1000);
    return false;
  }

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 API] Creating task...\r\n", 30,
                    1000);

  // ��������
  osThreadDef(PN532_ICCardTask, StartPN532_ICCardTask, PN532_TASK_PRIORITY, 0,
              PN532_TASK_STACK_SIZE);
  PN532_ICCardTaskHandle = osThreadCreate(osThread(PN532_ICCardTask), NULL);

  if (PN532_ICCardTaskHandle == NULL) {
    HAL_UART_Transmit(&huart4,
                      (uint8_t *)"[PN532 API] ERROR: Failed to create task\r\n",
                      42, 1000);
    return false;
  }

  HAL_UART_Transmit(&huart4,
                    (uint8_t *)"[PN532 API] Task created successfully\r\n", 39,
                    1000);
  return true;
}

bool PN532_IsTaskRunning(void) { return (PN532_ICCardTaskHandle != NULL); }

void PN532_ForceReset(void) {
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 API] Force reset...\r\n", 28,
                    1000);

  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_RESET);
  HAL_Delay(200);
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_SET);
  HAL_Delay(500);

  pn532_initialized = false; // ǿ�����³�ʼ��

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 API] Reset completed\r\n", 29,
                    1000);
}

/* ============================================================================
   ˽�к���ʵ��
   ============================================================================
 */
static void PN532_Init_Hardware(void) {
  HAL_UART_Transmit(
      &huart4, (uint8_t *)"[PN532 HW] Initializing hardware...\r\n", 38, 1000);

  // Ӳ����λ
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 HW] Hardware reset...\r\n", 30,
                    1000);
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_RESET);
  vTaskDelay(200);
  HAL_GPIO_WritePin(GPIOG, GPIO_PIN_10, GPIO_PIN_SET);
  vTaskDelay(3000);

  // ���ͻ��� + SAM����
  HAL_UART_Transmit(&huart4,
                    (uint8_t *)"[PN532 HW] Sending wakeup + SAM config...\r\n",
                    43, 1000);

  static const uint8_t fused_wakeup_sam[] = {
      0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0xFF, 0x03, 0xFD, 0xD4, 0x14, 0x01, 0x17, 0x00};

  HAL_UART_Transmit(&huart6, fused_wakeup_sam, sizeof(fused_wakeup_sam), 1000);
  vTaskDelay(1000);

  // ��ս��ջ���
  uint8_t dummy[256];
  HAL_UART_Receive(&huart6, dummy, 256, 100);

  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 HW] Hardware ready\r\n", 27,
                    1000);
}

static bool PN532_SearchCard(uint8_t *uid, uint8_t *uid_length) {
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 Search] Clearing buffer...\r\n",
                    35, 1000);

  uint8_t dummy[256];
  HAL_UART_Receive(&huart6, dummy, 256, 100);

  uart6_rx_index = 0;
  HAL_UART_Receive_IT(&huart6, &uart6_rx_buffer[0], 1);

  // ����Ѱ������
  HAL_UART_Transmit(
      &huart4, (uint8_t *)"[PN532 Search] Sending InListPassiveTarget...\r\n",
      47, 1000);

  uint8_t card_search[] = {0x00, 0x00, 0xFF, 0x04, 0xFC, 0xD4,
                           0x4A, 0x01, 0x00, 0xE1, 0x00};
  HAL_UART_Transmit(&huart6, card_search, sizeof(card_search), 1000);
  vTaskDelay(3000);

  // ��ӡ���յ�������
  char msg[50];
  sprintf(msg, "[PN532 Search] Received %d bytes\r\n", uart6_rx_index);
  HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);

  if (uart6_rx_index == 0) {
    HAL_UART_Transmit(
        &huart4, (uint8_t *)"[PN532 Search] ERROR: No response\r\n", 35, 1000);
    return false;
  }

  // ��ӡԭʼ��Ӧ��ʮ�����ƣ�
  HAL_UART_Transmit(&huart4, (uint8_t *)"[PN532 Search] Raw response: ", 29,
                    1000);
  for (int i = 0; i < uart6_rx_index; i++) {
    char hex[5];
    sprintf(hex, "%02X ", uart6_rx_buffer[i]);
    HAL_UART_Transmit(&huart4, (uint8_t *)hex, 3, 1000);
  }
  HAL_UART_Transmit(&huart4, (uint8_t *)"\r\n", 2, 1000);

  // ����D5 4B��Ӧ
  HAL_UART_Transmit(
      &huart4, (uint8_t *)"[PN532 Search] Parsing response...\r\n", 36, 1000);

  for (int i = 0; i < uart6_rx_index - 1; i++) {
    if (uart6_rx_buffer[i] == 0xD5 && uart6_rx_buffer[i + 1] == 0x4B) {
      sprintf(msg, "[PN532 Search] Found D5 4B at index %d\r\n", i);
      HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);

      if (uart6_rx_index >= i + 13) {
        uint8_t num_targets = uart6_rx_buffer[i + 2];
        sprintf(msg, "[PN532 Search] num_targets = %d\r\n", num_targets);
        HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);

        if (num_targets == 1) {
          *uid_length = uart6_rx_buffer[i + 7];
          sprintf(msg, "[PN532 Search] UID length = %d\r\n", *uid_length);
          HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);

          if (*uid_length >= 4 && *uid_length <= 7 &&
              i + 8 + *uid_length <= uart6_rx_index) {
            memcpy(uid, &uart6_rx_buffer[i + 8], *uid_length);

            HAL_UART_Transmit(
                &huart4, (uint8_t *)"[PN532 Search] UID extracted: ", 30, 1000);
            for (int j = 0; j < *uid_length; j++) {
              char hex[5];
              sprintf(hex, "%02X ", uid[j]);
              HAL_UART_Transmit(&huart4, (uint8_t *)hex, 3, 1000);
            }
            HAL_UART_Transmit(&huart4, (uint8_t *)"\r\n", 2, 1000);

            return true;
          } else {
            HAL_UART_Transmit(
                &huart4,
                (uint8_t
                     *)"[PN532 Search] ERROR: Invalid UID length or buffer\r\n",
                52, 1000);
          }
        } else {
          HAL_UART_Transmit(
              &huart4, (uint8_t *)"[PN532 Search] ERROR: num_targets != 1\r\n",
              40, 1000);
        }
      } else {
        HAL_UART_Transmit(
            &huart4, (uint8_t *)"[PN532 Search] ERROR: Response too short\r\n",
            42, 1000);
      }
    }
  }

  HAL_UART_Transmit(
      &huart4,
      (uint8_t *)"[PN532 Search] ERROR: No D5 4B found in response\r\n", 50,
      1000);
  return false;
}

static bool PN532_ReadAllSectors(PN532 *pn532, PN532_ReadResult *result) {
  uint8_t key[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
  int success_count = 0;
  int fail_count = 0;

  HAL_UART_Transmit(
      &huart4, (uint8_t *)"[PN532 Read] Starting to read sector 0 only...\r\n",
      47, 1000);

  // ֻ��ȡ����0
  int sector = 0;

  // ��֤����0
  if (PN532_MifareClassicAuthenticate_UART(pn532, result->uid,
                                           result->uid_length, sector, key,
                                           0x60) != PN532_STATUS_OK) {
    char msg[60];
    sprintf(msg, "[PN532 Read] Sector %2d: Auth FAILED\r\n", sector);
    HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);
    fail_count++;
  } else {
    // ��ȡ����0�Ŀ�0��1��2
    for (int block = 0; block < 3; block++) {
      uint8_t block_addr = sector * 4 + block; // 0, 1, 2

      if (PN532_MifareClassicReadWithUID_UART(
              pn532, block_addr, result->sector_data[sector][block],
              result->uid, result->uid_length) == PN532_STATUS_OK) {
        success_count++;
        char msg[60];
        sprintf(msg, "[PN532 Read] Block %2d: Read SUCCESS\r\n", block_addr);
        HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);
      } else {
        char msg[60];
        sprintf(msg, "[PN532 Read] Block %2d: Read FAILED\r\n", block_addr);
        HAL_UART_Transmit(&huart4, (uint8_t *)msg, strlen(msg), 1000);
        fail_count++;
      }
    }
  }

  char summary[80];
  sprintf(summary, "[PN532 Read] Summary: %d success, %d failed\r\n",
          success_count, fail_count);
  HAL_UART_Transmit(&huart4, (uint8_t *)summary, strlen(summary), 1000);

  return (fail_count == 0);
}

/**
 * @brief ��ȡ��1��������
 * @param array ������������ڴ洢��1��������
 * @param size ������������ڴ洢�����С
 * @return true=������Ч, false=������Ч
 */
bool PN532_GetBlock1Array(uint8_t *array, int *size) {
  if (array == NULL || size == NULL) {
    return false;
  }

  if (g_block1_array_size == 0) {
    return false; // û����Ч����
  }

  // ��������
  for (int i = 0; i < g_block1_array_size; i++) {
    array[i] = g_block1_array[i];
  }
  *size = g_block1_array_size;

  return true;
}

/**
 * @brief ��ȡ��2��һ���ֽ�
 * @return ��2��һ���ֽڵ�ʮ����ֵ�����������Ч����0
 */
uint8_t PN532_GetBlock2FirstByte(void) { return g_block2_first_byte; }
